
#include "io430.h"
#include "LCD16x2.h"


unsigned char DMILLAR1=0X30;
unsigned char UMILLAR1=0X30;
unsigned char CENTENA1=0X30;
unsigned char DECENA1=0X30;
unsigned char UNIDAD1=0X30;


 int Nad=0;
 int Vin=0;
 float i=0;
 int DAT =0;
 float  aux =0;
 float  aux1 =0;
  float  aux2 =0;
 

int main( void )
{
  // Stop watchdog timer to prevent time out reset
  WDTCTL = WDTPW + WDTHOLD;

  //DCO Trabajando a 1MHz aprox.
  BCSCTL1 = CALBC1_1MHZ;
  DCOCTL  = CALDCO_1MHZ;
  
  ADC10CTL0 = SREF_1+ADC10SHT_3+MSC+REFON+ADC10ON+ADC10IE;
  ADC10CTL0 &= ~REF2_5V;
  ADC10CTL1 = INCH_5+CONSEQ_2;
  ADC10AE0 |= BIT5;
  ADC10CTL0 |= ENC+ADC10SC;
  
  //____________________________________________________________________________
  P1SEL  = BIT1 + BIT2 ;                // Configurando las terminales P1.1 y P1.2
  P1SEL2 = BIT1 + BIT2 ;                // como parte del sistema UART
  P1DIR &= ~BIT1;                       // P1.1 <-- RXD
  P1DIR |= BIT2;                        // P1.2 --> TXD
  UCA0CTL1 |= UCSSEL_2;                 // SMCLK
  //--------9600bps----------------------------------------------
  UCA0BR0 = 104;                       // 1MHz 9600
  UCA0BR1 = 0;                         // 1MHz 9600
  UCA0MCTL = UCBRS0;                   // Modulation UCBRSx = 1
  //-------------------------------------------------------------


  UCA0CTL1 &= ~UCSWRST;                 // **Initialize USCI state machine**
  IE2 |= UCA0RXIE;                      // Enable USCI_A0 RX interrupt
 

 
  
  __bis_SR_register(GIE); 

  while(1)
  {

  } 
}

#pragma vector = ADC10_VECTOR
__interrupt void ADC10_ISR(void)
{
   //------------------------------------------------------------------------------
       //aux=(1023*(2.982/Nad));
       ////aux1=(i*Nad*100)/1024;
       //aux2=aux1/1000;
      // i=aux2-273;
       
    i=(((Nad*1.5)/100)*100)+2731;
     float num=i;
     int n = (int)(num < 0 ? (num - 0.5) : (num + 0.5));
      Vin=n-48;
      

    
      DAT=n;
                  DMILLAR1=0X30;
                  UMILLAR1=0X30;
                  CENTENA1=0X30;
                  DECENA1=0X30;
                  UNIDAD1=0X30;

                  while(DAT >=10000)
                   {
                      DAT-=10000;
                      DMILLAR1++;
                    }
                   while(DAT >=1000)
                   {
                      DAT-=1000;
                      UMILLAR1++;
                    }
                  while(DAT >=100)
                  {
                    DAT-=100;
                    CENTENA1++;
                   }
                  while(DAT >=10)
                  {
                    DAT-=10;
                    DECENA1++;
                    }
        UCA0TXBUF = DMILLAR1;
    while(!(IFG2&UCA0TXIFG)){}
             UCA0TXBUF = 0x30;
     while(!(IFG2&UCA0TXIFG)){}
        UCA0TXBUF = 0x30;
    while(!(IFG2&UCA0TXIFG)){}
                  


          UCA0TXBUF = UMILLAR1;
    while(!(IFG2&UCA0TXIFG)){}
            UCA0TXBUF = CENTENA1;
    while(!(IFG2&UCA0TXIFG)){}
          UCA0TXBUF = DECENA1;
    while(!(IFG2&UCA0TXIFG)){}
          UCA0TXBUF = UNIDAD1+DATi;
    
          UCA0TXBUF = 0xA;
      while(!(IFG2&UCA0TXIFG)){}


//      while(!(IFG2&UCA0TXIFG)){}
    //    __delay_cycles(100000);

            
//------------------------------------------------------------------------------

  TA1CCR1 = ADC10MEM;
  Nad=ADC10MEM;

  __delay_cycles(100000);
  

}
  